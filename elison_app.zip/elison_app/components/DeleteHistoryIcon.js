import React from 'react';
import { Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import Colors from '../constants/Colors';

export default function DeleteHistoryIcon(props) {
  return (
    <Ionicons
      style={props.style}
      name={Platform.OS === 'ios' ? `ios-${props.name}` : `md-${props.name}`}
      size={20}
      color={props.color}
    />
  );
}

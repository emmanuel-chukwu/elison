1. When a user makes a call that doesn't connect, the old messages are saved. Clear messageList if callstate != accept -- DONE
2. Call enters when a user is in a call {Only when user is dialling another user} -- DONE
3. Call does not ring when app is inactive
4. Add back button to callscreen -- DONE
5. Change numbers to saved names on history screen and ringer
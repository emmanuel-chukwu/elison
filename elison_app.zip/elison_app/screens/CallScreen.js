import React, {useState} from 'react';
import { ScrollView, View, Text, TextInput, TouchableNativeFeedback, ImageBackground, AsyncStorage} from 'react-native';
import styles from '../styles/Signup';
import Settings from './providers/Settings';

export default class CallScreen extends React.Component{
  state = {
    bgPicture: require('../assets/images/bg.png'),
    user: this.props.user,
    callerName: this.props.user.phone
  }

  componentDidMount() {
    Settings.getBackgroundPicture().then((bgPicture) => {this.setState({bgPicture})});
    let phone = this.state.user.phone;
    AsyncStorage.getItem(phone.toString()).then(details => {
      if (details != null) {
        details = JSON.parse(details);
        this.setState({callerName: `${details.firstName} ${details.lastName}`});
      } 
    })
  }

  renderCurrentContent = () => {
    return (
      <View>
        <ImageBackground source={this.state.bgPicture} style={{width: '100%', height: '100%'}}>
        <TouchableNativeFeedback onPress={this.props.stopCall}>
          <View style={{height: 40, left: 0, right: 0, backgroundColor: '#d80d4d', alignItems: 'center', alignContent: 'center'}}>
            <Text style={{lineHeight: 40, color: 'white'}}>Cancel Call</Text>
          </View>
        </TouchableNativeFeedback>
        <ScrollView keyboardShouldPersistTaps={'handled'}>
          <View style={{padding: 24, flex: 1, justifyContent: 'flex-end',}}>
            <View style={{marginHorizontal: 40, marginTop: 50}}>
              <Text style={[styles.getStartedText, styles.headerText,{fontSize: 20, marginBottom: 10, marginTop: 0, color: 'black'}, styles.font]}>Start Call</Text>
              <Text style={[styles.getStartedText,{marginBottom: 20}, styles.font]}>Start typing below to start a call with <Text style={{fontWeight: 'bold'}}>{this.state.callerName}</Text>.</Text>
            </View>
            <View>
              <InputArea sendMessage={this.props.sendMessage}/>
            </View>
          </View>
        </ScrollView>
        </ImageBackground>
      </View>
    );
  }

  render() {
    return (
      <View>
        {this.renderCurrentContent()}
      </View>
    )
  }
}

function InputArea(props) {
  const [message, changeMessage] = useState('');

  return (
    <View style={{alignContent: 'center', alignItems: 'center'}}>
      <TextInput
        editable
        value={message}
        placeholder="Enter Message Here"
        autoFocus={true}
        multiline
        numberOfLines={3}
        onChangeText={text => changeMessage(text)}
        style={[{height: 80, width: '50%'},styles.input]}
      />
      <TouchableNativeFeedback onPress = {() => sendMessage(message, props)}>
        <View style={{
            width: '50%',
            height: 50,
            lineHeight: 50,
            marginHorizontal: 15,
            marginBottom: 20,
            marginTop: 20,
            borderRadius: 5,
            backgroundColor: '#f04444',
        }}>
          <Text style={{
              fontFamily: 'sf',
              width: '100%', 
              textAlign: "center",
              color: '#fff',
              marginTop: 15   }}>Send</Text>
        </View>
      </TouchableNativeFeedback>
   </View>
  )
}

function sendMessage(message, props) {
  props.sendMessage(message, true);  
}
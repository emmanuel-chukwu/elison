import React, {useState} from 'react';
import { ScrollView, Keyboard, View, Text, TextInput, TouchableNativeFeedback, KeyboardAvoidingView, ImageBackground, Modal, Dimensions } from 'react-native';
import styles from '../styles/Signup';

import Settings from './providers/Settings';

export default class CallScreenReceiver extends React.Component {
  state = {
    bg: require('../assets/images/bg.png'),
    messageList: this.props.messageList,
    quota: 50,
    isTyping: this.props.isTyping,
  }

  componentDidMount() {
    this.keyboardDidShowListener = Keyboard.addListener('keyboardDidShow', this.startTyping);
    this.keyboardDidHideListener = Keyboard.addListener('keyboardDidHide', this.stopTyping);
    Settings.getBackgroundPicture().then(bgPicture => this.setState({bg: bgPicture.file}));
  }

  componentWillUnmount() {
    this.keyboardDidShowListener.remove();
    this.keyboardDidHideListener.remove();
  }

  componentWillReceiveProps(new_props) {
    this.setState({isTyping: new_props.isTyping, messageList: new_props.messageList})
  }

  startTyping = () => {
    this.scrollView.scrollToEnd({animated: true});
    this.props.emitTyping(true);
  }

  stopTyping = () => {
    this.props.emitTyping(false);
  }

  showTyping = () => {
    if (this.state.isTyping) {
      return (
        <View style={[{marginHorizontal: 10, marginTop: 20, marginBottom: 20}]}>
          <Text style={[{fontSize: 15, backgroundColor: '#f3f3f3', padding: 10, width: '35%', marginRight: 'auto', color: 'black', borderRadius: 10, fontStyle: 'italic'}, styles.font]}>Typing...</Text>
        </View>
      )
    }
    else return (<Text></Text>)
  } 
  
  currentContent() {
    if ((this.state.quota - this.props.messageList.length) < 1) {
      return (
        <View>
        <Modal animationType="slide" transparent={false} visible={true} onRequestClose={() => {this.props.changeCallState({incomingCall: false, outgoingCall: false, liveCall: false, startingCall: false})}} style={{background: 'white'}}>
            <View style={{ marginTop: 100, background: 'white', width: '80%', padding: 20, alignSelf: 'center', height: '80%', alignContent: 'center'}}>
              <View>
                <Text style={[{fontSize: 20, fontWeight: 'bold', textAlign: 'center', paddingBottom: 50}, styles.font]}>Call Quota Expired</Text>
                <Text style={[{fontSize: 16, textAlign: 'center'}, styles.font]}>You have exchanged 50/50 messages</Text>
                <Text style={[{fontSize: 14, textAlign: 'center', paddingBottom: 50}, styles.font]}>Call has ended!</Text>

                <TouchableNativeFeedback onPress={() => {this.props.changeCallState({incomingCall: false, outgoingCall: false, liveCall: false, startingCall: false})}}>
                  <View style={{
                    width: '50%',
                    height: 50,
                    lineHeight: 50,
                    marginHorizontal: 15,
                    marginBottom: 20,
                    marginTop: 20,
                    borderRadius: 5,
                    backgroundColor: '#f04444',
                    alignSelf: 'center'
                  }}>
                    <Text style={{
                      fontFamily: 'sf',
                      width: '100%', 
                      textAlign: "center",
                      color: '#fff',
                      marginTop: 15}}>Ok</Text>
                  </View>
                </TouchableNativeFeedback>
              </View>
            </View>
          </Modal>
        </View>
      )
    }
    return (
      <View>
        <ImageBackground source={this.state.bg} style={{width: '100%', height: '100%'}}>
      
        <Modal animationType="slide" transparent={false} visible={this.props.userLeftCall} onRequestClose={() => {this.props.changeCallState({incomingCall: false, outgoingCall: false, liveCall: false, startingCall: false})}} style={{background: 'white'}}>
            <View style={{ marginTop: 100, background: 'white', width: '80%', padding: 20, alignSelf: 'center', height: '80%', alignContent: 'center'}}>
              <View>
                <Text style={[{fontSize: 20, fontWeight: 'bold', textAlign: 'center', paddingBottom: 50}, styles.font]}>Leave Call</Text>
                <Text style={[{fontSize: 16, textAlign: 'center'}, styles.font]}>Chat Ended</Text>
                <Text style={[{fontSize: 14, textAlign: 'center', paddingBottom: 50}, styles.font]}>Call has ended!</Text>

                <TouchableNativeFeedback onPress={() => {this.props.changeCallState({incomingCall: false, outgoingCall: false, liveCall: false, startingCall: false})}}>
                  <View style={{
                    width: '50%',
                    height: 50,
                    lineHeight: 50,
                    marginHorizontal: 15,
                    marginBottom: 20,
                    marginTop: 20,
                    borderRadius: 5,
                    backgroundColor: '#f04444',
                    alignSelf: 'center'
                  }}>
                    <Text style={{
                      fontFamily: 'sf',
                      width: '100%', 
                      textAlign: "center",
                      color: '#fff',
                      marginTop: 15   }}>Ok</Text>
                  </View>
                </TouchableNativeFeedback>
              </View>
            </View>
          </Modal>

          <View style={{backgroundColor: '#16c1ad', paddingVertical: 10, marginTop: 24}}>
             <Text style={[styles.font, {textAlign: 'center'}]}>Your call quota: {this.state.quota - this.props.messageList.length}/{this.state.quota}</Text>
          </View>
            
          <TouchableNativeFeedback onPress={this.props.endCall}>
            <View style={{backgroundColor: 'red', paddingVertical: 10}}>
              <Text style={[styles.font, {textAlign: 'center', color: 'white'}]}>End Session</Text>
            </View>
          </TouchableNativeFeedback>

          <ScrollView style={{marginTop: 0, marginBottom: 70}} keyboardShouldPersistTaps={'handled'} ref={ref => this.scrollView = ref} onContentSizeChange={ (contentWidth, contentHeight) => {
          this.scrollView.scrollToEnd({animated: true}) }}>
            
            <View>
            {
              this.state.messageList.map((message, index) => {
                    if (message.sender == this.props.phones.phone || message.sender == this.props.phones.phoneE16) {
                      return (
                        <View key={index} style={[{marginHorizontal: 10, marginTop: 20}]}>
                          <Text style={[{fontSize: 15, backgroundColor: '#f04444', padding: 10, width: '80%', marginLeft: 'auto', color: 'white', borderRadius: 10, borderTopRightRadius: 0}, styles.font]}>{message.message}</Text>
                        </View>
                      )
                    }
                    return (
                      <View key={index} style={[{marginHorizontal: 10, marginTop: 20}]}>
                        <Text style={[{fontSize: 15, backgroundColor: '#f3f3f3', padding: 10, width: '80%', marginRight: 'auto', color: 'black', borderRadius: 10, borderTopLeftRadius: 0}, styles.font]}>{message.message}</Text>
                      </View>
                    )

              })
            }
            
            {this.showTyping()}
            </View>
          </ScrollView>
            <View>
              <InputArea sendMessage={this.props.sendMessage}/>
            </View>
        </ImageBackground>
      </View>)
  }

  render() {
    return (
      <KeyboardAvoidingView style={{flex: 1}} behavior="padding">
        {this.currentContent()}
      </KeyboardAvoidingView>
    )
  }
}

function InputArea(props) {
  const [message, updateMessage] = useState('');
  return (
    <View style={{alignContent: 'center', alignItems: 'center', display: 'flex', flexDirection: "row", justifyContent: 'center', marginTop: 20, backgroundColor: 'white', paddingVertical: 10, position: 'absolute', bottom: 0, left: 0, right: 0}}>
      <TextInput
        editable
        value={message}
        placeholder="Enter Message Here"
        onChangeText={text => updateMessage(text)}
        onSubmitEditing={() => _sendMessage(message, props, updateMessage)}
        style={[{height: 50, width: '80%', borderColor: 'grey', borderRightColor: 'transparent', borderRadius: 5, borderTopRightRadius: 0, borderBottomRightRadius: 0},styles.input]}
      />
      <TouchableNativeFeedback onPress = {() => _sendMessage(message, props, updateMessage)}>
        <View style={{
            width: '19%',
            height: 50,
            lineHeight: 50,
            borderRadius: 5,
            borderTopLeftRadius: 0,
            borderBottomLeftRadius: 0,
            backgroundColor: '#f04444',
        }}>
          <Text style={{
              fontFamily: 'sf',
              width: '100%', 
              textAlign: "center",
              color: '#fff',
              marginTop: 15   }}>Send</Text>
        </View>
      </TouchableNativeFeedback>
    </View>
  )
}

function _sendMessage(message, props, updateMessage) {
  Keyboard.dismiss();
  if (message.length < 1) return;
  updateMessage('');
  props.sendMessage(message);
}

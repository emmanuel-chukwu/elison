import React from 'react';
import { ScrollView, View, Text, TextInput, TouchableNativeFeedback, AsyncStorage} from 'react-native';

import * as Permissions from 'expo-permissions';
import * as Contacts from 'expo-contacts';

import styles from '../styles/Signup';
import PhoneIcon from '../components/PhoneIcon';

export default class ContactsScreen extends React.Component {
  state = {
    contacts: [],
    inMemoryContacts: [],
    isLoadingContacts: true,
    searchQuery: ''
  }

  componentDidMount() {
    this.fetchContacts();
  }
  
  fetchContacts = async () => {
    try {
      const {status} = await Permissions.askAsync(Permissions.CONTACTS);
      if (status == 'granted') {
        let {data} = await Contacts.getContactsAsync({fields: [Contacts.Fields.PhoneNumbers]});
        data = data.filter((contact) => {
          if (typeof(contact.phoneNumbers) != "undefined") return contact;
        });
        this.filterContacts(data);
        this.setState({
          contacts: data,
          inMemoryContacts: data,
          isLoadingContacts: false,
        });
      }
    } catch (err) {
      console.warn(err)
    }
  }

  filterContacts = (contacts) => {
    contacts.forEach(contact => {
      let phoneNumber = contact.phoneNumbers[0].number.split(" ").join("");
      AsyncStorage.setItem(phoneNumber.toString(), JSON.stringify(contact));
    });
  }

  searchContacts = (text) => {
    const filteredContacts = this.state.inMemoryContacts.filter(contact => {
        let contactLowerCase = (contact.firstName + ' ' + contact.lastName).toLowerCase();
        let searchQuery = text.toLowerCase();

        return contactLowerCase.indexOf(searchQuery) > -1;
    })
    if (text == '') return this.setState({contacts: this.state.inMemoryContacts});
    this.setState({contacts: filteredContacts});
  }
  
  _openCall(navigation, contact) {
    let startCall = navigation.getParam('startCall', null)
    startCall({data: contact, page: 'contacts'});
    navigation.navigate('Home');
  }

  currentContent() {
    if (this.state.isLoadingContacts) {
      return (
        <View style={{marginHorizontal: 40, marginTop: 20}}>
  
          <Text style={[styles.getStartedText, styles.headerText,{fontSize: 20, marginBottom: 10, marginTop: 0, color: 'black'}, styles.font]}>Loading Contacts</Text>
  
          <Text style={[styles.getStartedText,{marginBottom: 20}, styles.font]}>
              Fetching contacts...
          </Text>
  
        </View>
      )
    } 
    else {
      if (this.state.contacts === null) {
      return (
          <View style={{marginHorizontal: 40, marginTop: 20}}>
            <Text style={[styles.getStartedText, styles.headerText,{fontSize: 20, marginBottom: 10, marginTop: 0, color: 'black'}, styles.font]}>No Contacts Found</Text>    
            <Text style={[styles.getStartedText,{marginBottom: 20}, styles.font]}>No contacts found. This could be because there are no contacts on your device or because you have not given Elison permission to access your contacts. 
            </Text>
          </View>
        )
      } 
      else {
        return (
          <View>
          <View style={{marginHorizontal: 0, marginTop: 20}}>        
            <TextInput  
              editable
              placeholder="Search Contacts..."
              multiline
              numberOfLines={1}
              onChangeText={text => this.searchContacts(text)}
              style={[{height: 40, width: '100%'},styles.searchInput]}
            />
          </View>
          <View style={{marginHorizontal: 0, marginTop: 20}}>
            <Text style={[styles.getStartedText, styles.headerText,{fontSize: 20,marginBottom: 30, marginTop: 0, color: 'black', textAlign: 'left', marginHorizontal: 40}, styles.font]}>Total Contacts: {this.state.contacts.length}</Text>
            {
              this.state.contacts.map((contact, index) => {
                let initial = (contact.firstName != null) ? contact.firstName.substring(0,1) : '';       
                return (
                  <TouchableNativeFeedback key={index} onPress={() => {this._openCall(this.props.navigation, contact)}}>
                    <View style={[styles.contact, {paddingHorizontal: 40}]}>  
                      <View style={[{display: 'flex', flexDirection: 'row'}]}>  
                        <View style={styles.contactImg}>  
                          <Text style={[{color: 'white', textAlign: 'center', lineHeight: 30}, styles.font]}>{initial}</Text>  
                        </View>  
                        <Text style={styles.font}>{contact.firstName} {contact.lastName}</Text>
                      </View>
                      <PhoneIcon color="#16c1ad" name="call" style={[{transform: [{ rotate: '-90deg'}]}]} />
                    </View>
                  </TouchableNativeFeedback>
                )
              })
            }    
          </View>
        </View>
        );
      }
    }
  }

  render() {
    return (
      <ScrollView style={[styles.container]}>
        {this.currentContent()}
      </ScrollView>
    )
  }
}

ContactsScreen.navigationOptions = {
  title: 'Contacts',
};
import React from 'react';
import { ScrollView, View, Text, TouchableNativeFeedback, AsyncStorage, Modal } from 'react-native';
import DeleteHistoryIcon from '../components/DeleteHistoryIcon';
import HistoryArrowIcon from '../components/HistoryArrowIcon';
import styles from '../styles/Signup';

import History from './providers/History';
import Socket from './providers/SocketSend';
import Call from './providers/Call';

import CallScreen from './CallScreen';
import Ringer from './RingerScreen';
import CallScreenReceiver from './CallScreenReceiver';

const Calls = new Call();

export default class HistoryScreen extends React.Component {
  state = {
    history: [],
    callState: null,
    liveCall: false,
    startingCall: false,
    outgoingCall: false,
    userLeftCall: false,
    messageList: [],
    ringDetails: {},
    activeCallUser: {},
    outgoingCallState: null,
    isTyping: false,
    userPhone: this.props.userPhone,
    userPhoneE16: this.props.userPhoneE16
  }

  componentDidMount() {
    AsyncStorage.getItem('user')
    .then(value => {
      value = JSON.parse(value);
      this.setState({
        userPhoneE16: value.details.calling_code + value.phone,
        userPhone: '0' + value.phone,
      });
      Socket.connect(this);
      Socket.listenToNewMessages(this);
    });

    Calls.connect(this);
    this.fetchHistory();
  }

  fetchHistory = () => History.getHistory().then(async histories => {
      this.setState({history: histories});
      for (let index = 0; index < histories.length; index++) {
        const history = histories[index];
        if (!history.name) {
          let phone;
          let phoneE16;
          if (history.type == "sent") {
            phone = history.data.receiver;
            phoneE16 = history.data.receiver;
          }
          else {
            phone = history.data.sender;
            phoneE16 = history.data.senderE16 || "FALL_BACK";
          }
          await AsyncStorage.getItem(phone.toString()).then(details => {
            if (details != null) {
              details = JSON.parse(details);
              histories[index].name = `${details.firstName} ${details.lastName}`; 
              return;
            } 
            AsyncStorage.getItem(phoneE16.toString()).then(details => {              
              if (details != null) {
                details = JSON.parse(details);
                histories[index].name = `${details.firstName} ${details.lastName}`;
              }
            })
          })
        }
        if (index == histories.length - 1) {
          console.log(histories);
          this.setState({history: histories});
        }
      }
    });
  
  renderHistoryArrowIcon(type) {
    if (type == 'received') return <HistoryArrowIcon color="#0b87b9" name="arrow-round-down" style={{marginRight: 20}}/>
    if (type == 'sent') return <HistoryArrowIcon color="#0b87b9" name="arrow-round-up" style={{marginRight: 20}}/>
    if (type == 'missed') return <HistoryArrowIcon color="red" name="arrow-round-down" style={{marginRight: 20}}/>
  }
  
  _getTimeFormatted(time) {
    let seconds_since_time = Math.abs(time - new Date().getTime()) / 1000;
  
    if (seconds_since_time > 31557600) return `${Math.floor(seconds_since_time/31557600)}yr. ago`;
    if (seconds_since_time > 2592000) return `${Math.floor(seconds_since_time/2592000)}mth. ago`;
    if (seconds_since_time > 172800) return `${Math.floor(seconds_since_time/172800) + 1} days ago`;
    if (seconds_since_time > 86400) return `yesterday`;
    if (seconds_since_time > 3600) return `${Math.floor(seconds_since_time/3600)}hr. ago`;
    if (seconds_since_time > 60) return `${Math.floor(seconds_since_time/60)}min. ago`;
    return `Just now`;
  }
  
  deleteFromHistory(index) {
    History.deleteFromHistory(index);
    History.getHistory()
    .then(history => this.setState({history}))
  }

  renderHistory(data) {
    if (!data.data) return;
    if (data.data.receiver == this.state.userPhone || data.data.receiver == this.state.userPhoneE16) {
      return data.name ? data.name : data.data.sender;
    } 
    else return data.name ? data.name : data.data.receiver;
  }

  openContacts = () => {
    this.props.navigation.navigate('Contacts', {startCall: this.startCall})
  }

  changeCallState = ({incomingCall, outgoingCall, liveCall, startingCall}) => {
    this.setState({incomingCall, outgoingCall, liveCall, startingCall});
  }

  changeOutgoingCallState = (state) => this.setState({outgoingCallState: state});

  startCall = ({data, page}) => Calls.startCall({data, page});

  stopCall = () => {
    this.changeCallState({liveCall: false, outgoingCall: false, startingCall: false});
    this.setState({activeCallUser: {}});
  }

  startTyping = () => this.setState({isTyping: true});

  stopTyping = () => this.setState({isTyping: false});

  cancelCall = () => {
    console.log("cancelling call");
    History.saveToHistory({
      type: 'sent',
      data: this.state.ringDetails,
      time: new Date().getTime()
    });
    this.changeCallState({liveCall: false, outgoingCall: false, startingCall: false});
    this.setState({messageList: []});
    Socket.rejectCall();
  }

  endCall = () => {
    this.setState({
      messageList: [],
      liveCall: false,
      outgoingCall: false,
      startingCall: false
    });
    Socket.endCall();
  }

  sendMessage = (message, start = null) => Calls.sendMessage(message, start);

  currentContent() {
    if (this.state.history.length > 0) {
      return (
          <View style={{marginHorizontal: 20, marginTop: 20, marginBottom: 50}}>
            {
              this.state.history.map((data, index) => {
                let time = this._getTimeFormatted(data.time);
                return (
                    <View style={[styles.contact, {paddingHorizontal: 10}]} key={index}>
                      <TouchableNativeFeedback onPress={() => this.startCall({data, page: "history"})}>
                        <View style={[{display: 'flex', flexDirection: 'row'}]}>
                          <View>
                            {this.renderHistoryArrowIcon(data.type)}
                          </View>
                          <View>
                            <Text style={[{fontSize: 17},styles.font]}>{this.renderHistory(data)}</Text>
                            <Text style={styles.font}>{time}</Text>
                          </View>
                        </View>
                      </TouchableNativeFeedback>
                      <TouchableNativeFeedback onPress={() => this.deleteFromHistory(index)}>
                        <View style={{height: 50, width: 50, alignContent: "center", alignItems: "center"}}>
                          <DeleteHistoryIcon color="red" name="trash" />
                        </View>
                      </TouchableNativeFeedback>    
                    </View>
                )
              })
            }
    
          </View>
      );
    }
  
    return (
        <View style={{marginHorizontal: 40, marginTop: 20, marginBottom: 50}}>
          <Text style={[styles.getStartedText, styles.headerText,{fontSize: 20, marginBottom: 10, marginTop: 0, color: 'black'}, styles.font]}>No Calls Found</Text>
          <Text style={[styles.getStartedText,{marginBottom: 20}, styles.font]}>You have not made a call yet. 
            <Text style={[styles.getStartedText,{textDecorationLine: 'underline', color: 'skyblue'}, styles.font]} onPress={this.openContacts}> Make Call</Text>
          </Text>
        </View>
    );
  }

  render() {
    if (this.state.startingCall) {
      return <CallScreen 
        caller={this.state.ringDetails}
        stopCall={this.stopCall}
        messageList={this.state.messageList}
        sendMessage={this.sendMessage}
        user={this.state.activeCallUser}
        />
    } 
    else if (this.state.outgoingCall) {
      return <Ringer 
          type = {"outgoing"}
          callState={this.state.outgoingCallState}
          caller={this.state.ringDetails}
          cancelCall = {this.cancelCall}
        />
    }
    else if (this.state.liveCall) {
      return  <Modal animationType="slide" transparent={false} visible={true} onRequestClose={() => {this.endCall}} style={{background: 'white'}}>
        <View style={{flex: 1}}>
        <CallScreenReceiver
          caller={this.state.ringDetails}
          messageList={this.state.messageList}
          endCall={this.endCall}
          emitTyping={Calls.emitTyping}
          sendMessage={this.sendMessage}
          user={this.state.activeCallUser}
          userLeftCall={this.state.userLeftCall}
          isTyping={this.state.isTyping}
          changeCallState={this.changeCallState}
          phones={{phone: this.state.userPhone, phoneE16: this.state.userPhoneE16}}
          />
          </View>
        </Modal>

    }
    return (
      <View style={{flex: 1}}>
        <TouchableNativeFeedback onPress={this.openContacts}>
          <View style={{height: 40, left: 0, right: 0, backgroundColor: '#403cc0', alignItems: 'center', alignContent: 'center'}}>
            <Text style={{lineHeight: 40, color: 'white'}}>Open Contacts</Text>
          </View>
        </TouchableNativeFeedback>
        <ScrollView style={styles.container}>
          {this.currentContent()}
        </ScrollView>
      </View>
    )
  }

}

HistoryScreen.navigationOptions = {
  title: 'Calls',
};

import React from 'react';
import { ScrollView, View, Text, TouchableNativeFeedback, Image, AsyncStorage } from 'react-native';

import CallButtonIcon from '../components/CallButtonIcon';

export default class RingerScreen extends React.Component {
  state = {
    callerName: this.props.type == 'incoming' ? this.props.caller.sender : this.props.caller.receiver,
    callState: this.props.callState,
    type: this.props.type,
  }

  componentDidMount() {
    let phone; let phoneE16;
    if (this.props.type == 'incoming') {
      phone = this.props.caller.sender;
      phoneE16 = this.props.caller.senderE16;
    }
    else {
      phone = this.props.caller.receiver;
      phoneE16 = this.props.caller.receiver;
    }
    AsyncStorage.getItem(phone.toString()).then(details => {
      if (details != null) {
        details = JSON.parse(details);
        return this.setState({callerName: `${details.firstName} ${details.lastName}`});
      } 
      AsyncStorage.getItem(phoneE16.toString()).then(details => {              
        if (details != null) {
          details = JSON.parse(details);
          return this.setState({callerName: `${details.firstName} ${details.lastName}`});
        } 
      })
    })
  }

  componentWillReceiveProps(new_props) {
    this.setState({callState: new_props.callState})
  }

  showCallState = () => {
    if (this.state.type == 'incoming') {
      return <Text style={{color: '#fff', fontSize: 19}}>Incoming Message</Text>;
    }

    let style = {color: '#fff', fontSize: 19};

    if (this.state.callState == null) {
      return <Text style={style}>Placing call...</Text>
    }
    else if (this.state.callState == 'ringing') {
      return <Text style={style}>Ringing...</Text>
    } 
    else if (this.state.callState == 'busy') {
      return <Text style={style}>User is on another call!</Text>
    } 
    else if (this.state.callState == 'accepted') {
      return <Text style={style}>Ongoing call</Text>
    } 
    else if (this.state.callState == 'rejected') {
      return <Text style={style}>User is busy!</Text>
    } 
    else if (this.state.callState == 'ignored') {
      return <Text style={style}>User is not answering</Text>
    } 
    else if (this.state.callState == 'out-of-range') {
      return <Text style={style}>User is out of range!</Text>
    }
  }

  renderCallButtons = () => {
    let styles = {
      flexContainer: { display: 'flex', flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 150 },
      callButton: { height: 70, width: 70, backgroundColor: 'red', borderRadius: 50, alignContent: 'center', alignItems: 'center', paddingVertical: 25 },
      CallButtonIcon: {fontSize: 18}
    };
    if (this.state.type == 'incoming') {
      return (
        <View style={styles.flexContainer}>
          <TouchableNativeFeedback onPress={this.props.rejectCall}>
              <View style={styles.callButton}>
                <CallButtonIcon color="#fff" name="close" style={styles.CallButtonIcon}/>
              </View>
           </TouchableNativeFeedback>
            <TouchableNativeFeedback onPress={this.props.acceptCall}>
              <View style={[styles.callButton, {backgroundColor: 'green'}]}>
                <CallButtonIcon color="#fff" name="checkmark" style={styles.CallButtonIcon}/>
              </View>
            </TouchableNativeFeedback>
        </View>
      )
    } 
    else {
      return (
        <View style={[styles.flexContainer, {alignContent: 'center', alignItems: 'center', justifyContent: 'center'}]}>
          <TouchableNativeFeedback onPress={this.props.cancelCall}>
            <View style={[styles.callButton, {alignSelf: 'center'}]}>
              <CallButtonIcon color="#fff" name="close" style={styles.CallButtonIcon}/>
            </View>
          </TouchableNativeFeedback>
        </View>
      )
    }
  }

  currentStyle = () => {
    if (this.props.type == 'incoming') return {backgroundColor: '#000', paddingVertical: 100, paddingHorizontal: 50};
    else return {backgroundColor: '#000', paddingVertical: 30, paddingHorizontal: 50}
  }

  render() {
    return (
      <ScrollView style={this.currentStyle()}>
        <View style={{paddingBottom: 40, alignContent: 'center', alignItems: 'center'}}>
          {this.showCallState()}
          <Image source={require('../assets/images/user-icon.jpg')} style={{height: 120, width: 120, borderRadius: 100, marginVertical: 30}}/>
          <Text style={{color: '#fff', fontSize: 18}}>{this.state.callerName}</Text>
        </View>
        {this.renderCallButtons()}
      </ScrollView>
    )
  }
}

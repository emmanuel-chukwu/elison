import Constants from 'expo-constants';
import React from 'react';
import { SectionList, Image, StyleSheet, Text, View, TouchableNativeFeedback } from 'react-native';

import * as DocumentPicker from 'expo-document-picker';
import * as FileSystem from 'expo-file-system';

import Settings from './providers/Settings';

export default class SettingsScreen extends React.Component {
    state = {
      sections: [
        { data: [{ value: "fetching..." }], title: 'Change Ringtone' },
        { data: [{ value: "fetching..." }], title: 'Change Call Background Picture' },
      ]
    }
  
    static navigationOptions = {
     title: 'Change Options',
    };     

    componentDidMount() {
      Settings.getRingTone()
      .then(ringtone => this.updateRingTone(ringtone.uri));

      Settings.getBackgroundPicture()
      .then(bgPicture => this.updateBackgroundPicture(bgPicture.uri))
    }

    removeSlashes(string) {
      return string.split('/')[string.split('/').length - 1];
    }

    updateRingTone(ringtone) {
      let sections = this.state.sections;
      sections[0].data[0].value = this.removeSlashes(ringtone);
      this.setState({sections})
    }

    updateBackgroundPicture(bgPicture) {
      let sections = this.state.sections;
      sections[1].data[0].value = this.removeSlashes(bgPicture);
      this.setState({sections})
    }

    openPicker = async (item) => {  
      let file;
      if (item.slice(-3) == 'mp3' || item.slice(-3) == 'mp4' || item.slice(-3) == 'wav' || item.slice(-3) == 'ogg' || item.slice(-3) == 'mp4') {
        file = await DocumentPicker.getDocumentAsync({
          type: "audio/*",
        });
        if (file.type == 'success') {
          FileSystem.moveAsync({
            from: file.uri,
            to: FileSystem.documentDirectory + this.removeSlashes(file.name)
          })
          Settings.updateRingTone(FileSystem.documentDirectory + this.removeSlashes(file.name));
          this.updateRingTone(FileSystem.documentDirectory + this.removeSlashes(file.name))
        }
      } else {
        file = await DocumentPicker.getDocumentAsync({
          type: "image/*",
        });
        if (file.type == 'success') {
          FileSystem.moveAsync({
            from: file.uri,
            to: FileSystem.documentDirectory + this.removeSlashes(file.name)
          })
          Settings.updateBackgroundPicture(FileSystem.documentDirectory + this.removeSlashes(file.name));
          this.updateBackgroundPicture(FileSystem.documentDirectory + this.removeSlashes(file.name))
        } 
      }
    }

    _renderSectionHeader = ({ section }) => {
     return <SectionHeader title={section.title} />;
    };

    _renderItem = ({ item }) => {
      return (
        <SectionContent>
          <TouchableNativeFeedback onPress={() => this.openPicker(item.value)}>
            <Text style={[styles.sectionContentText, {color: 'skyblue', textDecorationLine: 'underline'}]}>{item.value}</Text>
          </TouchableNativeFeedback>
        </SectionContent>
      );
    };

    render() {
      return (
          <SectionList
            style={[styles.container,{paddingBottom: 100}]}
            renderItem={this._renderItem}
            renderSectionHeader={this._renderSectionHeader}
            stickySectionHeadersEnabled={true}
            keyExtractor={(item, index) => index}
            ListHeaderComponent={ListHeader}
            sections={this.state.sections}
          />
      );
    }
}

const ListHeader = () => {
  const { manifest } = Constants;

  return (
    <View>
    <View style={{marginHorizontal: 10, marginTop: 10, borderRadius: 10, height: 350, backgroundColor: "#000"}}>
      <Image source={require('../assets/images/m21.jpg')} style={{width: '100%', height: '100%', borderRadius: 10}}/>
    </View>
    <View style={styles.titleContainer}>
      <View style={styles.titleIconContainer}>
        <AppIconPreview iconUrl={manifest.iconUrl} />
      </View>

      <View style={styles.titleTextContainer}>
        <Text style={styles.nameText} numberOfLines={1}>
          {manifest.name}
        </Text>

        <Text style={styles.slugText} numberOfLines={1}>
          @{manifest.slug}
        </Text>

        <Text style={styles.descriptionText}>{manifest.description}</Text>
      </View>
    </View>
    </View>
  );
};

const SectionHeader = ({ title }) => {
  return (
    <View style={styles.sectionHeaderContainer}>
      <Text style={styles.sectionHeaderText}>{title}</Text>
    </View>
  );
};

const SectionContent = props => {
  return <View style={styles.sectionContentContainer}>{props.children}</View>;
};

const AppIconPreview = ({ iconUrl }) => {
  return <Image source={require('../assets/images/user-icon.jpg')} style={{ width: 64, height: 64, borderRadius: 50 }} resizeMode="cover" />;
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  titleContainer: {
    paddingHorizontal: 15,
    paddingTop: 15,
    paddingBottom: 15,
    flexDirection: 'row',
  },
  titleIconContainer: {
    marginRight: 15,
    paddingTop: 2,
  },
  sectionHeaderContainer: {
    backgroundColor: '#fbfbfb',
    paddingVertical: 8,
    paddingHorizontal: 15,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: '#ededed',
  },
  sectionHeaderText: {
    fontSize: 14,
  },
  sectionContentContainer: {
    paddingTop: 8,
    paddingBottom: 12,
    paddingHorizontal: 15,
  },
  sectionContentText: {
    color: '#808080',
    fontSize: 14,
  },
  nameText: {
    fontWeight: '600',
    fontSize: 18,
  },
  slugText: {
    color: '#a39f9f',
    fontSize: 14,
    backgroundColor: 'transparent',
  },
  descriptionText: {
    fontSize: 14,
    marginTop: 6,
    color: '#4d4d4d',
  },
  colorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  colorPreview: {
    width: 17,
    height: 17,
    borderRadius: 2,
    marginRight: 6,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: '#ccc',
  },
  colorTextContainer: {
    flex: 1,
  },
});


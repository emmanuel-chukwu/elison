import React, {useState} from 'react';

import Intro from './templates/Intro';
import Registration from './templates/PhoneRegistration';
import Verification from './templates/PhoneVerification';

export default function OnboardingScreen(props) {
  const [state, updateState] = useState({});
  const [page, changePage] = useState('intro');
  if (page === 'intro') {
    return <Intro 
        changePage = {changePage}
      />;
  } else if (page === 'registration') {
    return <Registration 
        changePage = {changePage}
        updateState = {updateState}
      />;
  } else if (page === 'verification') {
    return <Verification 
        changePage = {changePage}
        state = {state}
        updateState = {updateState}
        setUser={props.setUser}
      />;
  }
}



import React, {useState} from 'react';
import {
  Image,
  ScrollView,
  Text,
  View,
} from 'react-native';

import Button from '../../components/Button';

import styles from '../../../styles/Signup';

export default function IntroScreen(props) {
  return (
    <View style={styles.container}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.contentContainer}>

        <View style={styles.getStartedContainer}>

          <Text style={[styles.getStartedText, styles.headerText, styles.font]}>Welcome to Elison</Text>

          <View style={styles.titleIconContainer}>
            <Image source={require('../../../assets/images/m1.jpg')} style={styles.image} />
            <Text style={styles.iconText}>-</Text>
            <Image source={require('../../../assets/images/m2.gif')} style={styles.image} />
            <Text style={styles.iconText}>-</Text>
            <Image source={require('../../../assets/images/m4.jpg')} style={styles.image} />
          </View>

          <Text style={[styles.getStartedText, styles.font]}>
            Turn your messages into phone calls with the tap of a button!
          </Text>
          
        </View>

      </ScrollView>
    
      <Button text="Sign In" callback={props.changePage} redirectPage="registration"/>

    </View>
  );
}
import React, {useState, useEffect} from 'react';
import {
  Image,
  KeyboardAvoidingView,
  Text,
  TouchableNativeFeedback,
  View,
  TextInput
} from 'react-native';

import styles from '../../../styles/Signup';

export default function PhoneRegistrationScreen(props) {

  const [value, changeInputText] = useState('');
  const [countryDetails, changeCountryDetails] = useState({country_flag: require("../../../assets/images/loader.gif"), country_name: "Fetching country...", calling_code: '+1'});
  
  useEffect(() => {
    fetch('https://api.ipgeolocation.io/getip')
    .then(response => response.json())
    .then(data => {
      fetch(`https://api.ipgeolocation.io/ipgeo?apiKey=fa7761ac2c2c405aa360712971b642b6&ip=${data.ip}`)
      .then(response => response.json())
      .then(data => {
        data.country_flag = {uri: data.country_flag};
        changeCountryDetails(data);
      })
    })
  }, [])

  return (
    <View style={styles.container}>
      <KeyboardAvoidingView
        behavior="padding"
        enabled>

        <View style={{
            shadowColor: '#000',
            shadowOffset: { width: 0, height: 1 },
            shadowOpacity: 0.8,
            shadowRadius: 10,
            elevation: 1,
            height: 50,
            display: 'flex',
            justifyContent: 'center',
            flexDirection: 'row',
            alignItems: 'center',
            marginTop: 23, 
            fontSize: 20, 
            marginBottom: 0,
            borderBottomColor: '#000'
        }}>
          <Image
            style={{
                width: 20,
                marginRight: 8, 
                height: 20
            }}
            source={require('../../../assets/images/icon.png')}  
            />
          <Text style={[styles.getStartedText, {lineHeight: 50, fontSize: 17, fontWeight: 'bold'}, styles.font]}>Elison</Text>
        </View>

        <View style={styles.getStartedContainer}>

        <Text style={[styles.getStartedText, styles.headerText,{fontSize: 20, marginBottom: 10, marginTop: 0}, styles.font]}>Enter Phone Number</Text>
        <Text style={[styles.getStartedText,{marginBottom: 20}, styles.font]}>Please confirm your country code and enter your phone number. Country is: <Text style={[styles.getStartedText,{textDecorationLine: 'underline', color: 'skyblue'}, styles.font]}>{countryDetails.country_name}</Text></Text>

        <View style={{marginBottom: 50, display: 'flex', justifyContent: 'center', flexDirection: 'row',}}>

          <Image
            source={countryDetails.country_flag}
            style={{
                width: 35,
                marginTop: 10,
                marginRight: 15,
                height: 20
            }}
           />
           <Text>{countryDetails.calling_code}</Text>
          <TextInput
            editable
            maxLength={10}
            value={value}
            placeholder="Enter Phone Number"
            autoFocus={true}
            keyboardType="phone-pad"
            onChangeText={text => changeInputText(text)}
            style={[{textAlign: 'center'},styles.input]}
          />
        </View>
          
        </View>

      <TouchableNativeFeedback
        onPress = {() => {_handlePress(props, value, countryDetails)}}
      >
        <View style={{
            width: '80%',
            height: 50,
            lineHeight: 50,
            marginHorizontal: 35,
            marginBottom: 20,
            borderRadius: 5,
            backgroundColor: '#f04444',
        }}>
          <Text style={{
              fontFamily: 'sf',
              width: 300, 
              textAlign: "center",
              color: '#fff',
              marginTop: 15   }}>Verify</Text>
        </View>
      </TouchableNativeFeedback>

      </KeyboardAvoidingView>
    </View>
  );
}

_handlePress = (props, value, countryDetails) => {
    if (value.substring(0,1) == 0) value = value.substring(0,1);
    let E164Number = countryDetails.calling_code + value;
    let code = Math.floor(100000 + Math.random() * 900000);
    fetch(`https://elison.glitch.me/?phone=${E164Number}&code=${code}`)
    props.changePage('verification');
    props.updateState({
      phone: value,
      code,
      countryDetails
    });

}
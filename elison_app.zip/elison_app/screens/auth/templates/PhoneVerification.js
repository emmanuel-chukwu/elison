import React, {useState, useEffect} from 'react';
import {
  Image,
  KeyboardAvoidingView,
  Text,
  TouchableNativeFeedback,
  View,
  TextInput,
  AsyncStorage
} from 'react-native';

import styles from '../../../styles/Signup';

export default function PhoneVerificationScreen(props) {
  const [value, changeInputText] = useState('');
  const [code, changeCode] = useState('');
  const [error, changeError] = useState(null);
  let lastFourDigitsPhone = props.state.phone.substring(props.state.phone.length - 4);

  useEffect(() => {
    changeCode(props.state.code);
  },[])

  return (
    <View style={styles.container}>
      <KeyboardAvoidingView
        behavior="padding"
        enabled>

        <View style={{
            shadowColor: '#000',
            shadowOffset: { width: 0, height: 1 },
            shadowOpacity: 0.8,
            shadowRadius: 10,
            elevation: 1,
            height: 50,
            display: 'flex',
            justifyContent: 'center',
            flexDirection: 'row',
            alignItems: 'center',
            marginTop: 23, 
            fontSize: 20, 
            marginBottom: 0,
            borderBottomColor: '#000'
        }}>
          <Image
            style={{
                width: 20,
                marginRight: 8, 
                height: 20
            }}
            source={require('../../../assets/images/icon.png')}  
            />
          <Text style={[styles.getStartedText, {lineHeight: 50, fontSize: 17, fontWeight: 'bold'}, styles.font]}>Elison</Text>
        </View>

        <View style={styles.getStartedContainer}>

        <Text style={[styles.getStartedText, styles.headerText,{fontSize: 20, marginBottom: 10, marginTop: 0}, styles.font]}>Enter Verification Code</Text>
        <Text style={[styles.getStartedText,{marginBottom: 20}, styles.font]}>Enter 6-digit code we sent to *******{lastFourDigitsPhone}. It can take up to 2mins to enter. 
          {/* <TouchableNativeFeedback onPress={() => {resendCode(props, changeError, changeCode)}}>
            <Text style={[styles.getStartedText,{textDecorationLine: 'underline', color: 'skyblue'}, styles.font]}> Resend
            </Text>
          </TouchableNativeFeedback> */}
        </Text>

        {
          renderErrors(error)
        }

        <TextInput
            editable
            maxLength={6}
            value={value}
            placeholder="Enter Code"
            autoFocus={true}
            keyboardType="phone-pad"
            onChangeText={text => changeInputText(text)}
            style={[{textAlign: 'center', marginBottom: 30},styles.input]}
          />
        </View>

      <TouchableNativeFeedback
        onPress = {() => {_handlePress(code, props, value, changeError)}}
      >
        <View style={{
            width: '80%',
            height: 50,
            lineHeight: 50,
            marginHorizontal: 35,
            marginBottom: 20,
            borderRadius: 5,
            backgroundColor: '#f04444',
        }}>
          <Text style={{
              fontFamily: 'sf',
              width: 300, 
              textAlign: "center",
              color: '#fff',
              marginTop: 15   }}>Complete</Text>
        </View>
      </TouchableNativeFeedback>

      </KeyboardAvoidingView>
    </View>
  );
}

function resendCode(props, changeError, changeCode) {
    let value = props.phone;
    if (value.substring(0,1) == 0) value = value.substring(0,1);
    let E164Number = props.state.countryDetails.calling_code + value;
    let code = Math.floor(100000 + Math.random() * 900000);
    fetch(`https://elison.glitch.me/?phone=${E164Number}&code=${code}`)
    changeCode(code);
    // changeError('resent');
}

function _handlePress(code, props, value, changeError) {
  if (value == code) {
    changeError('correct-code');
    let user = {
      phone: props.state.phone,
      details: props.state.countryDetails
    };
    AsyncStorage.setItem('user', JSON.stringify(user))
    props.setUser(user)
  } else {
    changeError('wrong-code');
  }
}

function renderErrors (error){
  if (error == null) return <Text></Text>;
  
  if (error == 'correct-code') {
    return <View style={{backgroundColor: '#16c1ad', paddingVertical: 10, paddingHorizontal: 20, marginBottom: 20}}>
        <Text style={[styles.font, {textAlign: 'center'}]}>Verification successful!</Text>
      </View>
  }
  
  if (error == 'wrong-code') {
    return <View style={{backgroundColor: 'red', paddingVertical: 10, paddingHorizontal: 20, marginBottom: 20}}>
        <Text style={[styles.font, {textAlign: 'center', color: 'white'}]}>Oops! It seems you entered the wrong code.</Text>
      </View>
  }
  
  if (error == 'resent') {
    return <View style={{backgroundColor: '#16c1ad', paddingVertical: 10, paddingHorizontal: 20, marginBottom: 20}}>
        <Text style={[styles.font, {textAlign: 'center'}]}>A new code has been sent by SMS.</Text>
      </View>
  }
}
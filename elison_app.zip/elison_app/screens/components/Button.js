import React from 'react';
import {
  Text,
  TouchableNativeFeedback,
  View,
} from 'react-native';

export default function Button(props) {
  return (
      <TouchableNativeFeedback
        onPress = {() => {_handlePress(props)}}
      >
        <View style={{
            width: '80%',
            height: 50,
            lineHeight: 50,
            marginHorizontal: 35,
            marginBottom: 20,
            borderRadius: 5,
            backgroundColor: '#f04444',
        }}>
          <Text style={{
              fontFamily: 'sf',
              width: 300, 
              textAlign: "center",
              color: '#fff',
              marginTop: 15   }}>{props.text}</Text>
        </View>
      </TouchableNativeFeedback>
  );
}

function _handlePress(props) {
  props.callback(props.redirectPage);
}
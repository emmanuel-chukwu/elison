import Socket from './SocketSend';
import History from './History';
import Settings from './Settings';

import * as Permissions from 'expo-permissions';
import {Notifications} from 'expo';
import { Audio } from 'expo-av'; 
import { INTERRUPTION_MODE_ANDROID_DO_NOT_MIX, INTERRUPTION_MODE_IOS_DO_NOT_MIX } from 'expo-av/build/Audio';

const RingTone = new Audio.Sound();

class Call {

  parent;
  ringTone;

  connect = parent => this.parent = parent;

  changeCallState = ({incomingCall, outgoingCall, liveCall, startingCall}) => {
    this.parent.setState({incomingCall, outgoingCall, liveCall, startingCall})
  }

  startTyping = () => this.parent.setState({isTyping: true});

  stopTyping = () => this.parent.setState({isTyping: false});

  emitTyping = (state) => Socket.emitTyping(this.parent, state);

  startCall = ({data, page}) => {
    let phone;
    if (page == 'history') {
      if (data.type == 'received' || data.type == 'missed') {
        phone = data.data.sender
      } else {
        phone = data.data.receiver
      }
    } else {
      phone = data.phoneNumbers[0].number.split(" ").join("");
    }
    this.parent.changeCallState({liveCall: false, outgoingCall: false, startingCall: true});
    this.parent.setState({activeCallUser: {data, phone}});
  }

  placeCall = (message) => {
    let receiver = this.parent.state.activeCallUser.phone;
    let room =  Math.round(Math.random() * 100000000);
    Socket.placeCall(this.parent, {room, sender: this.parent.state.userPhoneE16, name: '', receiver, message});
    History.saveToHistory({
      type: 'sent',
      data: {start: true, room, sender: this.parent.state.userPhone, senderE16: this.parent.state.userPhoneE16, name: '', receiver, message},
      time: new Date().getTime()
    });
    this.parent.changeCallState({liveCall: false, outgoingCall: true, startingCall: false});
    setTimeout(() => {
      if (!this.parent.state.liveCall && this.parent.state.outgoingCall) {
        if (this.parent.state.callState != null) {
          Socket.ignoreCall();
        } else {
          Socket.outOfRange();
        }        
      }
    }, 30000);
  }
  
  sendMessage = (message, start) => {
    if (start != null) {
      return this.placeCall(message);
    }
    Socket.sendMessage({sender: this.parent.state.userPhoneE16, name: '', message});
  }
  
  endCall = () => {
    this.parent.changeCallState({liveCall: false, incomingCall: false, outgoingCall: false, startingCall: false,});
    this.setState({messageList: []});
    Socket.endCall();
  }

  acceptCall = () => {
    History.saveToHistory({
      type: 'received',
      data: this.parent.state.ringDetails,
      time: new Date().getTime()
    });
    this.stopRinging(true);
    this.parent.changeCallState({liveCall: true, incomingCall: false});
    Socket.acceptCall();
  }

  rejectCall = () => {
    History.saveToHistory({
      type: 'received',
      data: this.parent.state.call_data,
      time: new Date().getTime()
    });
    this.FinishRing();
    this.parent.setState({messageList: []});
    Socket.rejectCall();
  }

  registerPhoneCall(data) {
    this.setupRingTone();
    this.showCallNotification(data);
    try {
      this.parent.changeCallState({liveCall: false, incomingCall: true});
      this.Ring(data);
    } catch (error) {
      console.log(error)
    }
  }
  

  saveMissedCallToHistory = (data) => {
    History.saveToHistory({
      type: 'missed',
      data,
      time: new Date().getTime()
    });
  }
}

export default Call;
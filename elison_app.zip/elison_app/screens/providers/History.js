import { AsyncStorage } from 'react-native';

class History {
    getHistory = () => {
        return AsyncStorage.getItem('history').then(value => {
            if (value == null) return [];
            return JSON.parse(value)
            })
    }
    updateHistory = (history) => {
        AsyncStorage.setItem('history', JSON.stringify(history));
    }
    saveToHistory = (new_history) => {
        this.getHistory()
        .then(data => {
            if (data.length > 30) data.pop();
            data.unshift(new_history);
            this.updateHistory(data);
        });
    }
    deleteFromHistory = (index) => {
        this.getHistory()
        .then(data => {
            data.splice(index, 1);
            this.updateHistory(data.reverse());
        });
    }
    deleteHistory = () => {
        this.updateHistory([]);
    }
}

export default new History();
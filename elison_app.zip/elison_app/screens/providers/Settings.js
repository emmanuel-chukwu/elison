import { AsyncStorage } from 'react-native';

class Settings {
    getSettings = () => {
        return AsyncStorage.getItem('settings').then(value => {
            if (value == null) return {};
            return JSON.parse(value);
            })
    }
    getRingTone = () => {
        return this.getSettings()
        .then(data => {
            if (data.ringtone) return {uri: data.ringtone, file: {uri: data.ringtone}};
            return { uri: '../../assets/tones/tone1.mp3', file: require('../../assets/tones/tone1.mp3')};
        })
    }
    getBackgroundPicture = () => {
        return this.getSettings()
        .then(data => {
            if (data.bgPicture) return {uri: data.bgPicture, file: {uri: data.bgPicture}};
            return {uri: '../../assets/images/bg.png', file: require('../../assets/images/bg.png')};
        })
    }
    updateRingTone = (tone) => {
        this.getSettings()
        .then(data => {
            data.ringtone = tone;
            AsyncStorage.setItem('settings', JSON.stringify(data));
        })
    }
    updateBackgroundPicture = (image) => {
        this.getSettings()
        .then(data => {
            data.bgPicture = image;
            AsyncStorage.setItem('settings', JSON.stringify(data));
        })
    }
}

export default new Settings();
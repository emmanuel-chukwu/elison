import SocketIOClient from 'socket.io-client';
import { AsyncStorage } from 'react-native';

class Socket {

    socket;
    room;

    connect = (parent) => {
        this.socket = SocketIOClient('https://elison.glitch.me');
        this.socket.on('connect', () => {
            if (parent.state.liveCall) {
                this.socket.emit('active-call', {rejoin: true, room: this.room});
            }
        });
    }

    listenToNewMessages = (parent) => {
        this.socket.on('active-call', data => {
            if (data.room != this.room) return;

            if (data.end) {
                if (!parent.state.liveCall) parent.FinishRing();
                return parent.setState({messageList: [], userLeftCall: true});
            }

            if (data.sender != parent.state.userPhone && data.sender != parent.state.userPhoneE16 && data.type_event) {
                if (data.typing) {
                    parent.startTyping();
                } else {
                    parent.stopTyping();
                }
            }
        
            if (data.new_message) {
                let messageList = parent.state.messageList;
                messageList.push(data);
                parent.setState({messageList});
            }

            if (parent.state.outgoingCall) {
                if (data.busy) {
                    parent.changeOutgoingCallState('busy');
                    return this.closeCall(parent);
                }
                if (data.ringing) {
                    return parent.changeOutgoingCallState('ringing')
                }
                if (data.accept) {
                    parent.changeOutgoingCallState('accepted');
                    return parent.changeCallState({liveCall: true, incomingCall: false, outgoingCall: false, startingCall: false})
                }
                if (data.cancel) {
                    parent.changeOutgoingCallState('rejected');
                    return this.closeCall(parent);
                }
                if (data.ignored) {
                    parent.changeOutgoingCallState('ignored');
                    return this.closeCall(parent);
                }
                if (data.out_of_range) {
                    parent.changeOutgoingCallState('out-of-range');
                    return this.closeCall(parent);
                }
            }
          });
    }

    closeCall = (parent) => {
        setTimeout(() => {
            parent.setState({liveCall: false, incomingCall: false, outgoingCall: false, startingCall: false, messageList: []});
            parent.changeOutgoingCallState(null);
            return this.endCall();
        }, 3000);
    }

    placeCall = (parent, {room, sender, name, receiver, message}) => {
        this.room = room;
        let messageList = parent.state.messageList;
        messageList.push({start: true, room, sender, name, receiver, message});
        parent.setState({ringDetails: {room, sender, name, receiver, message}, messageList})
        this.socket.emit('call', {start: true, room, sender, name, receiver, message});  
        AsyncStorage.setItem('active-call', 1);
    }

    sendMessage = ({sender, name, message}) => {
        this.socket.emit('active-call', {new_message: true, room: this.room, sender, name, message});
    }

    endCall = () => {
        AsyncStorage.setItem('active-call', 0);
        this.socket.emit('active-call', {end: true, room: this.room})
    }

    acceptCall = () => {
        this.socket.emit('active-call', {accept: true, room: this.room})
    }

    emitTyping = (parent, state) => {
        this.socket.emit('active-call', {type_event: true, typing: state, sender: parent.state.userPhoneE16, room: this.room});
    }

    rejectCall = () => {
        this.socket.emit('active-call', {cancel: true, room: this.room});
    }

    ignoreCall = () => {
        this.socket.emit('active-call', {ignored: true, room: this.room});
    }

    outOfRange = () => {
        this.socket.emit('active-call', {out_of_range: true, room: this.room});
    }
}

export default new Socket();
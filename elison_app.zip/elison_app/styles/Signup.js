import {StyleSheet, Platform} from 'react-native';

export default StyleSheet.create({
  font: {
    fontFamily: 'sf'
  },
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  contentContainer: {
    paddingTop: 30,
  },
  welcomeContainer: {
    alignItems: 'center',
    marginTop: 10,
    marginBottom: 20,
  },
  welcomeImage: {
    width: 100,
    height: 80,
    resizeMode: 'contain',
    marginTop: 3,
    marginLeft: -10,
  },
  getStartedContainer: {
    alignItems: 'center',
    marginHorizontal: 50,
  },
  homeScreenFilename: {
    marginVertical: 7,
    marginTop: 30
  },
  codeHighlightText: {
    color: 'rgba(96,100,109, 0.8)',
  },
  codeHighlightContainer: {
    backgroundColor: 'rgba(0,0,0,0.05)',
    borderRadius: 3,
    paddingHorizontal: 4,
  },
  headerText: {
    fontSize: 30,
    marginTop: 50,
    lineHeight: 50,
    paddingTop: 20,
    marginBottom: 10,
    textAlign: 'center',
  },
  getStartedText: {
    fontSize: 15,
    color: 'rgba(96,100,109, 1)',
    lineHeight: 24,
    textAlign: 'center',
  },
  navigationFilename: {
    marginTop: 5,
  },
  helpContainer: {
    marginTop: 15,
    marginBottom: 15,
    margin: 'auto',
    alignItems: 'center',
    marginHorizontal: 50,
  },
  helpLink: {
    paddingVertical: 15,
  },
  helpLinkText: {
    fontSize: 14,
    color: '#2e78b7',
  },
  image: {
      height: 50,
      width: 50,
      borderRadius: 50,
  },
  iconText: {
    // color: 'gainsboro',
    lineHeight: 50
  },
  titleIconContainer: {
    marginTop: 180,
    marginBottom: 20,
    height:'auto',
    backgroundColor: 'transparent',
    display: 'flex',
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    flexWrap: 'wrap',
    alignItems: 'flex-start'
  },
  input: {
    width: '70%',
    borderColor: '#fff',
    borderBottomColor: "grey",
    borderBottomWidth: 1,
    paddingBottom: 3,
    fontSize: 17,
  },
  searchInput: {
    width: '70%',
    borderColor: '#fff',
    borderColor: "gainsboro",
    borderWidth: 1,
    paddingHorizontal: 10,
    borderRadius: 4,
    paddingBottom: 3,
    fontSize: 16,
    alignSelf: 'center',
  },
  contact: {
    fontSize: 16,
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: 60,
    lineHeight: 60,
    alignContent: 'center'
  },
  contactImg: {
    height: 30,
    width: 30,
    marginRight: 15,
    borderRadius: 50,
    backgroundColor: '#f04444',
  }
})